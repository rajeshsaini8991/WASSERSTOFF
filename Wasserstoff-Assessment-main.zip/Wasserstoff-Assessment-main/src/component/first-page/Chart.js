import React from "react";

const Chart = () => {
  return (
    <>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "27px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "28px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "24px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "38px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "36px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "36px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "38px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "24px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "19px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "18px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "16px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "17px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "19px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "27px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "28px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "24px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#FF708B",
        }}
      ></div>
      <div
        style={{
          height: "24px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "18px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "17px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "26px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "20px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "38px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "16px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "20px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "12px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "16px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "20px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "12px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "12px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "16px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "20px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "12px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "31px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "16px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "20px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "25px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "14px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
      <div
        style={{
          height: "10px",
          width: "18px",
          background: "#DBDFF1",
        }}
      ></div>
    </>
  );
};

export default Chart;
